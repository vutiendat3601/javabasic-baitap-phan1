package com.datvutech.answer.bai32;

public class NVHopDong extends LDNgoaiBienChe implements XetKhenThuong {

    @Override
    public double tinhKhenThuong() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tinhKhenThuong'");
    }

}
