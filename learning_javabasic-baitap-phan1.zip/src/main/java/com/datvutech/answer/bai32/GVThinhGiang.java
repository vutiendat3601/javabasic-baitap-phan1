package com.datvutech.answer.bai32;

public class GVThinhGiang extends LDNgoaiBienChe {

}
