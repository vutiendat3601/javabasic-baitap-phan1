package com.datvutech.answer.bai32;

public class NVCoHuu extends LDBienChe implements XetKhenThuong {

    @Override
    public double tinhKhenThuong() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tinhKhenThuong'");
    }

}
