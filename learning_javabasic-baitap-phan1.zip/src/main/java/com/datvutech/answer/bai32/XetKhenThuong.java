package com.datvutech.answer.bai32;

public interface XetKhenThuong {
    double tinhKhenThuong();
}
