package com.datvutech.answer.bai32;

public class LDNgoaiBienChe extends NguoiLaoDong {

    @Override
    public double tinhLuong() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tinhLuong'");
    }

    @Override
    public void nhap() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'nhap'");
    }

    @Override
    public void xuat() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'xuat'");
    }

}
