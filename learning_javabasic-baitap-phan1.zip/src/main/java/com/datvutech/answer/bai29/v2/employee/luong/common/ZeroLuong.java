package com.datvutech.answer.bai29.v2.employee.luong.common;

public class ZeroLuong extends Luong {

    @Override
    public float tinhLuong() {
        return 0;
    }

}
